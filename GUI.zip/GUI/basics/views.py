
# # from django.shortcuts import render
# # from django.http import HttpResponse
# # import pandas as pd
# # import pickle

# # def home(request):
# #     return render(request, 'index.html')

# # def predict(request):
# #     if request.method == 'POST':
# #         # Collect user inputs from the webpage
# #         user_inputs = {
# #             'age': int(request.POST['age']),
# #             'job': request.POST['job'],
# #             'marital': request.POST['marital'],
# #             'education': request.POST['education'],
# #             'default': request.POST['default'],
# #             'balance': int(request.POST['balance']),
# #             'housing': request.POST['housing'],
# #             'loan': request.POST['loan'],
# #             'contact': request.POST['contact'],
# #             'day': int(request.POST['day']),
# #             'month': request.POST['month'],
# #             'duration': int(request.POST['duration']),
# #             'campaign': int(request.POST['campaign']),
# #             'pdays': int(request.POST['pdays']),
# #             'previous': int(request.POST['previous']),
# #             'poutcome': request.POST['poutcome'],
# #             # Add other features as needed
# #         }

# #         # Convert user inputs into a DataFrame
# #         input_df = pd.DataFrame([user_inputs])
# #         categorical_columns = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'month', 'poutcome']
# #         # Apply one-hot encoding to the input data using the same categorical columns used during training
# #         input_df_encoded = pd.get_dummies(input_df, columns=categorical_columns)

# #         # Load the trained model
# #         model_path = "C:\\Users\\Dell\\Desktop\\KARUNADU PROJECT\\GUI\\bank_term_deposit_model.sav"  # Update with the actual path
# #         rf = pickle.load(open(model_path, "rb"))

# #         # # Ensure the input_df_encoded has the same columns as x_train
# #         # missing_cols = set(x_train.columns) - set(input_df_encoded.columns)
# #         # for col in missing_cols:
# #         #     input_df_encoded[col] = 0

# #         # # Reorder columns to match the order during training
# #         # input_df_encoded = input_df_encoded[x_train.columns]

# #         # Make predictions using the trained model
# #         prediction = rf.predict(input_df_encoded)

# #         # Pass the prediction to the 'result.html' template
# #         return render(request, 'result.html', {'prediction': prediction[0]})
    
# #     return HttpResponse("Invalid request method")
      








# from django.shortcuts import render
# from django.http import HttpResponse
# import pandas as pd
# import pickle
# from sklearn.model_selection import train_test_split
# from sklearn.ensemble import RandomForestClassifier
# def home(request):
#      return render(request, 'index.html')
# # Load the dataset
# bank_data_path = "C:\\Users\\Dell\\Desktop\\KARUNADU PROJECT\\GUI\\train.csv"
# df = pd.read_csv(bank_data_path)

# # Specify categorical columns for one-hot encoding
# categorical_columns = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'month', 'poutcome']

# # Apply one-hot encoding to the entire DataFrame
# df_encoded = pd.get_dummies(df, columns=categorical_columns)

# # Separate features (x) and target variable (y)
# x = df_encoded.drop(['y_bool'], axis=1)
# y = df_encoded['y_bool']

# # Split the data into training and testing sets
# x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# # Create and train the Random Forest model
# rf = RandomForestClassifier(n_estimators=100)
# rf.fit(x_train, y_train)



# def predict(request):
#     if request.method == 'POST':
#         # Collect user inputs from the webpage
#         user_inputs = {
#             'age': int(request.POST['age']),
#             'job': request.POST['job'],
#             'marital': request.POST['marital'],
#             'education': request.POST['education'],
#             'default': request.POST['default'],
#             'balance': int(request.POST['balance']),
#             'housing': request.POST['housing'],
#             'loan': request.POST['loan'],
#             'contact': request.POST['contact'],
#             'day': int(request.POST['day']),
#             'month': request.POST['month'],
#             'duration': int(request.POST['duration']),
#             'campaign': int(request.POST['campaign']),
#             'pdays': int(request.POST['pdays']),
#             'previous': int(request.POST['previous']),
#             'poutcome': request.POST['poutcome'],
#             # Add other features as needed
#         }

#         # Convert user inputs into a DataFrame
#         input_df = pd.DataFrame([user_inputs])

#         # Apply one-hot encoding to the input data using the same categorical columns used during training
#         input_df_encoded = pd.get_dummies(input_df, columns=categorical_columns)

#         # Ensure the input_df_encoded has the same columns as x_train
#         missing_cols = set(x_train.columns) - set(input_df_encoded.columns)
#         for col in missing_cols:
#             input_df_encoded[col] = 0

#         # Reorder columns to match the order during training
#         input_df_encoded = input_df_encoded[x_train.columns]

#         # Print the input_df_encoded for debugging
#         print("Input Data:")
#         print(input_df_encoded)

#         # Make predictions using the trained model
#         prediction = rf.predict(input_df_encoded)

#         # Print the prediction for debugging
#         print("Prediction:")
#         print(prediction)

#         # Pass the prediction to the 'result.html' template
#         return render(request, 'result.html', {'prediction': prediction[0]})

#     return HttpResponse("Invalid request method")














from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
def home(request):
      return render(request, 'index.html')
# Load the dataset
bank_data_path = "C:\\Users\\Dell\\Desktop\\KARUNADU PROJECT\\GUI\\train.csv"
df = pd.read_csv(bank_data_path)

# Specify categorical columns for one-hot encoding
categorical_columns = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'month', 'poutcome']

# Apply one-hot encoding to the entire DataFrame
df_encoded = pd.get_dummies(df, columns=categorical_columns)

# Separate features (x) and target variable (y)
x = df_encoded.drop(['y_bool'], axis=1)
y = df_encoded['y_bool']

# Create and train the Random Forest model
rf = RandomForestClassifier(n_estimators=100)
rf.fit(x, y)

def predict(request):
    if request.method == 'POST':
        # Collect user inputs from the webpage
        user_inputs = {
            'age': int(request.POST['age']),
            'job': request.POST['job'],
            'marital': request.POST['marital'],
            'education': request.POST['education'],
            'default': request.POST['default'],
            'balance': int(request.POST['balance']),
            'housing': request.POST['housing'],
            'loan': request.POST['loan'],
            'contact': request.POST['contact'],
            'day': int(request.POST['day']),
            'month': request.POST['month'],
            'duration': int(request.POST['duration']),
            'campaign': int(request.POST['campaign']),
            'pdays': int(request.POST['pdays']),
            'previous': int(request.POST['previous']),
            'poutcome': request.POST['poutcome'],
            # Add other features as needed
        }

        # Convert user inputs into a DataFrame
        input_df = pd.DataFrame([user_inputs])

        # Apply one-hot encoding to the input data using the same categorical columns used during training
        input_df_encoded = pd.get_dummies(input_df, columns=categorical_columns)

        # Ensure the input_df_encoded has the same columns as x
        missing_cols = set(x.columns) - set(input_df_encoded.columns)
        for col in missing_cols:
            input_df_encoded[col] = 0

        # Reorder columns to match the order during training
        input_df_encoded = input_df_encoded[x.columns]

        # Print the input_df_encoded for debugging
        print("Input Data:")
        print(input_df_encoded)

        # Make predictions using the trained model
        prediction = rf.predict(input_df_encoded)

        # Print the prediction for debugging
        print("Prediction:")
        print(prediction)

        # Pass the prediction to the 'result.html' template
        return render(request, 'result.html', {'prediction': prediction[0]})

    return HttpResponse("Invalid request method")
